export interface Log {
    type: string
    payload: string
    time: Date
}
