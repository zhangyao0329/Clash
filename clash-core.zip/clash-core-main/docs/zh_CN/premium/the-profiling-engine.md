---
sidebarTitle: "功能: 性能分析引擎"
sidebarOrder: 8
---

# 性能分析引擎

https://github.com/Dreamacro/clash-tracing

```yaml
profile:
    tracing: true
```
