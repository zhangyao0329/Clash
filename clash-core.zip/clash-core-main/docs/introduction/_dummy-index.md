---
sidebarTitle: What is Clash?
sidebarOrder: 1
---

<!-- This file is used as a dummy sidebar item that always links to / -->
